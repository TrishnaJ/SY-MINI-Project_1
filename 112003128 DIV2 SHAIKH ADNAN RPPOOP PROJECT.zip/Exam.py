#Name: Shaikh Adnan
#Div: 2
#Batch: S3
#MIS: 112003128
#RPPOOP Project
#Questions in data.json file

from cProfile import label
import tkinter
from tkinter import *
from tkinter import font
from tkinter import messagebox as mb
import time
import json
import random

a = random.randint(1111,9999)

root = tkinter.Tk()
root.title("Exam")
root.geometry("700x600")
root.config(background="white")

hour=StringVar()
minute=StringVar()
second=StringVar()

hour.set("00")
minute.set("00")
second.set("00")

hourEntry= Entry(root, width=3, font=("Cambria",18,""),
				textvariable=hour)
hourEntry.place(x=1300,y=50)

minuteEntry= Entry(root, width=3, font=("Cambria",18,""),
				textvariable=minute)
minuteEntry.place(x=1350,y=50)

secondEntry= Entry(root, width=3, font=("Cambria",18,""),
				textvariable=second)
secondEntry.place(x=1400,y=50)


def submit():
	try:
		temp = int(hour.get())*3600 + int(minute.get())*60 + int(second.get()) + 60
	except:
		print("Please input the right value")

	while temp >-1:
		
		# divmod(firstvalue = temp//60, secondvalue = temp%60)
		mins,secs = divmod(temp,60)

		hours=0
		if mins >60:
			hours, mins = divmod(mins, 60)

		hour.set("{0:2d}".format(hours))
		minute.set("{0:2d}".format(mins))
		second.set("{0:2d}".format(secs))

		root.update()
		time.sleep(1)

		if (temp == 0):
			mb.showinfo("Time Countdown", "Time's up ")
		
		temp -= 1


class Exam:

    def __init__(self):

        self.q_no=0
        self.display_title()
        self.display_question()
        self.opt_selected=IntVar()
        self.opts=self.radio_buttons()
        self.display_options()
        self.buttons()
        self.data_size=len(question)
        self.correct=0

        submit()

    def display_result(self):

        wrong_count = self.data_size - self.correct
        correct = f"Correct: {self.correct}"
        wrong = f"Wrong: {wrong_count}"
        score = int(self.correct / self.data_size * 100)
        result = f"Score: {score}%"

        mb.showinfo("Result for roll no.", f"{a}\n{result}\n{correct}\n{wrong}")

    def check_ans(self, q_no):

        if self.opt_selected.get() == answer[q_no]:
            return True

    def next_btn(self):

        if self.check_ans(self.q_no):
            self.correct += 1

        self.q_no += 1

        if self.q_no==self.data_size:
            self.display_result()
            root.destroy()

        else:

            self.display_question()
            self.display_options()

    def buttons(self):

        next_button = Button(root, text="Next",command=self.next_btn,
        width=10,bg="blue",fg="white",font=("Cambria",16,"bold"))
        next_button.place(x=1400,y=900)
        quit_button = Button(root, text="Quit", command=root.destroy,
        width=5,bg="black", fg="white",font=("Cambria",16," bold"))
        quit_button.place(x=100,y=900)

    def display_options(self):

        val=0
        self.opt_selected.set(0)

        for option in options[self.q_no]:
            self.opts[val]['text']=option
            val+=1
 

    def display_question(self):

        q_no = Label(root, text=question[self.q_no], width=60,
        font=( 'Cambria' ,16, 'bold' ), anchor= 'w' )
        q_no.place(x=70, y=100)

    def display_title(self):

        title = Label(root, text="Online Examination",
        width=100, bg="purple",fg="white", font=("ariel", 20, "bold"))

        title.place(x=0, y=2)

    def radio_buttons(self):

        q_list = []
        y_pos = 150

        while len(q_list) < 4:

            radio_btn = Radiobutton(root,text=" ",variable=self.opt_selected,
            value = len(q_list)+1,font = ("ariel",14))
            q_list.append(radio_btn)
            radio_btn.place(x = 100, y = y_pos)
            y_pos += 40

        return q_list


with open('data.json') as f:
    data = json.load(f)

question = (data['question'])
options = (data['options'])
answer = (data[ 'answer'])

def runExam():
    exam = Exam()
    Exam()


labeltext = Label(
    root,
    text = "****************\nOnline Exam\n________________",
    background="white",
    font = ("Cambria", 40, "bold")
)

labeltext.pack(pady=(80,0))

labeltext1 = Label(
    root,
    text = "This is an interface to give exam. The test would be comprising of 4 questions, and score would be displayed in the form of percentage",
    background="white",
    font = ("Cambria", 15)
)

labeltext1.pack(pady=(50,0))

labeltext2 = Label(
    root,
    text = "Random roll number shall be generated for each attempt.",
    background="white",
    font = ("Cambria", 15)
)

labeltext2.pack(pady=(40,0))

def startIspressed():
    labeltext.destroy()
    labeltext1.destroy()
    labeltext2.destroy()
    btnStart.destroy()
    b.destroy()
    btnPassword.destroy()
    lblRules.destroy()
    runExam()


btnStart = Button(
    root,
    background="lightgreen",
    height=3,
    width=20,
    text="Start",
    font = ("Cambria", 14),
    command=startIspressed,
)

btnStart.pack(pady=(60,0))

def changetext():
	b.config(text=a)
    
b = tkinter.Label(
    root,
    text="",
    height=3,
    width=15,
    background="pink",
    font="bold"
)

b.pack(pady=(30,0))

btnPassword = Button(
    root,
    text="Press to know roll number",
    height=2,
    width=30,
    background="lightblue",
    border=0,
    font = ("Cambria", 14),
    command=changetext,
)

btnPassword.pack(pady=(30,0))

lblRules = Label(
    root,
    text="Test would be of 60 seconds,\nClick a radio button for selecting choice, next to proceed forward or quit to end the exam",
    width=100,
    background="black",
    foreground="yellow",
    font=("Times",15,"bold")
)

lblRules.pack(pady=(150,0))

root.mainloop()